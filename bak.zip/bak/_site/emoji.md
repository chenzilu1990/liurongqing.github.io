# 表情

![表情列表](./assets/images/emoji_sheet.jpg)