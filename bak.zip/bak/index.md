---
layout: default
title: magician's blog
---
